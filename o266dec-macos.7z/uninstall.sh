#!/bin/sh

prefix=/usr/local
rm -f $prefix/lib/libo266dec.0.1.0.dylib
rm -f $prefix/lib/libo266dec.0.dylib
rm -f $prefix/lib/libo266dec.dylib
rm -rf $prefix/include/o266
rm -f $prefix/lib/pkgconfig/o266dec.pc
