Tencent O266 Decoder Evaluation Release

Evaluation release limited to 600 frames of decode.

If an old version has been installed,
 please uninstall the old version before installing the new version.

Use of the O266 library requires a custom VLC Media Player. Please visit our Github page here for build instructions:
https://github.com/TencentCloud/O266player

---
For Mac installation:
To install, run in Terminal:
sh ./install.sh

To uninstall, run in Terminal:
sh ./uninstall.sh

---
For Windows installation:
Please visit our GitHub page for the Windows-specific build instructions of the custom VLC player: 
https://github.com/TencentCloud/O266player
