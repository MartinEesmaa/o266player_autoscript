#!/bin/sh

prefix=/usr/local
install -dv $prefix/include/o266 $prefix/lib/pkgconfig
install -m 755 -v lib/libo266dec.0.1.0.dylib $prefix/lib
install -m 755 -v lib/libo266dec.0.dylib $prefix/lib
install -m 755 -v lib/libo266dec.dylib $prefix/lib
install -m 644 -v include/o266/o266dec_api.h $prefix/include/o266
install -m 644 -v lib/pkgconfig/o266dec.pc $prefix/lib/pkgconfig
